package buscaguitarra_versao4;

public class Guitarra extends Instrumento {
	
	public Guitarra(String serialNumber, double preco, GuitarSpec spec) {
		super(serialNumber, preco, spec);
	}

			
}
