package buscaguitarra_versao4;

public class Bandolim extends Instrumento {
	
	public Bandolim(String serialNumber, double preco, BandolimSpec spec) {
		super(serialNumber, preco, spec);
	}

}
